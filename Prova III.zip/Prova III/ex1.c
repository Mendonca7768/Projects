#include <stdio.h>    
  int main() {
  float altura = 0;
  
  printf("Digite sua altura: ");
  scanf("%f", &altura);
  
  if (altura <=1.20){
  printf("Acesso negado. Altura insuficiente\n");
  } else if(altura >=1.20 && altura <=1.39) {
  printf("Acesso Permitido apenas com acompanhante adulto.\n");
  } else {
  printf("Acesso Liberado! Boa diversão.\n");
  }
  return 0;
}

