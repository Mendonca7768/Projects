#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
  srand(time(NULL));
  int moeda = (rand() % 90) + 10;
  
  printf("Você abriu o baú do tesouro misterioso e ganhou %d moedas\n", moeda);
  
  return 0;
  
  }

