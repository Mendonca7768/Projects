#include <stdio.h>
int main() {
  int opcao = 0;
  printf("[1] - Água da Fonte (Recupera 10 HP)\n");
  printf("[2] - Poção de Cura (Recupera 50 HP)\n");
  printf("[3] - Elixir Supremo (Recupera 100 HP)\n");
  printf("Digite o que você quer consumir\n");
  scanf("%d", &opcao);
  
  switch (opcao) {
  case 1:
    printf("Você consumiu Água da fonte e recuperou 10 de HP\n");
    printf("Sua vida atual é de 10 HP\n");
    break;
  case 2:
    printf("Você consumiu Poção de cura e recuperou 50 de HP\n");
    printf("Sua vida atual é de 50 HP\n");
    break;
  case 3:
    printf("Você consumiu Elixir supremo e recuperou 100 de HP\n");
    printf("Sua vida atual é de 100 HP\n");
    break;
    default:
    printf("Opção inválida!\n");
    }
    return 0;
    
  }
    
    
